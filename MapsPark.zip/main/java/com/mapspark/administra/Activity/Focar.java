package com.mapspark.administra.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;
import com.mapspark.administra.R;

public class Focar extends AppCompatActivity {
    private Bitmap imageBitmap;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    private ImageView imagePlaca;
    private ImageButton btnFoto;
    private Button botaoFocar;
    private EditText placa;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_focar );

        imagePlaca = findViewById(R.id.imagePlaca);
        imagePlaca.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                fotoPlaca();
            }
        });
    }



    public void botaoFocar(View view){

        placa = findViewById ( R.id.edtPlacaForoId );

        String txtPlaca = placa.getText ().toString ().trim ();

        //Validar se os campos foram preenchidos
        if (!txtPlaca.isEmpty ()) {
            FocarVeiculos();

        } else {
            alert ( "Preencha a Placa !" );
        }

    }

    private void fotoPlaca() {
        Intent takePictureIntent = new Intent( MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            imageBitmap = (Bitmap) extras.get("data");
            imagePlaca.setImageBitmap(imageBitmap);
            //imageBitmap = (Bitmap) extras.get("data");

            buscaTexto();
        }
    }

    private void buscaTexto() {

        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(imageBitmap);

        FirebaseVisionTextRecognizer detector = FirebaseVision.getInstance()
                .getOnDeviceTextRecognizer();

        Task<FirebaseVisionText> result =
                detector.processImage(image)
                        .addOnSuccessListener(new OnSuccessListener<FirebaseVisionText> () {
                            @Override
                            public void onSuccess(FirebaseVisionText firebaseVisionText) {
                                alert (firebaseVisionText.getText ());
                                EditText txtPlaca = findViewById(R.id.edtPlacaForoId);
                                txtPlaca.setText(firebaseVisionText.getText ());

                                // Task completed successfully
                                // ...
                            }
                        })
                        .addOnFailureListener(
                                new OnFailureListener () {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        alert ( "Texto não encontrado!" );
                                        // Task failed with an exception
                                        // ...
                                    }
                                });


        // FirebaseVisionTextDetector detector = FirebaseVision.getInstance().getVisionTextDetector();

    }



    private void FocarVeiculos ( ) {
        Bundle bundle = getIntent().getExtras();
        final String s=bundle.getString("emailfor");

        Intent i = new Intent(Focar.this, Movimentos.class);
        EditText txtPlaca = findViewById( R.id.edtPlacaForoId);
        i.putExtra("placa", txtPlaca.getText ().toString ());
        i.putExtra("emailfor", s);
        startActivity(i);
        finish ();
    }



    private void alert (String msg) {
        Toast.makeText ( Focar.this, msg, Toast.LENGTH_SHORT ).show ();
    }

}

