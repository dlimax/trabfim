package com.mapspark.administra.conexao;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;


public class estacionaLogado {
    public static String getIdEstacio(){

        FirebaseAuth autenticacao =  acessar.getFireAutenticacao ();
        return autenticacao.getCurrentUser().getUid();

    }

    public static FirebaseUser getEstacioAtual(){
        FirebaseAuth Estacio = acessar.getFireAutenticacao();
        return Estacio.getCurrentUser();
    }

    public static boolean atualizarTipoEstacio(String tipo){

        try {

            FirebaseUser user = getEstacioAtual();
            UserProfileChangeRequest profile = new UserProfileChangeRequest.Builder()
                    .setDisplayName(tipo)
                    .build();
            user.updateProfile(profile);
            return true;

        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}
