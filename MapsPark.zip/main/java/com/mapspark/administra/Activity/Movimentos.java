package com.mapspark.administra.Activity;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mapspark.administra.R;
import com.mapspark.administra.conexao.acessar;
import com.mapspark.administra.helper.Base64Custom;
import com.mapspark.administra.modelo.MovInfor;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

 public class Movimentos extends AppCompatActivity {
        private EditText placaTexto;
        private EditText edtDataEntrada;
        private EditText edtCelular;
        private EditText edtDataSaida;
        private EditText edtHoraEntrada;
        private EditText edtHoraSaida;
        private EditText edtValorPagar;
        private ImageButton botaoGravar,botaoCalc,botaoSms;
        private MovInfor movimentos;
        private FirebaseAuth autenticacao;
        private DatabaseReference referencia = FirebaseDatabase.getInstance ().getReference ();

        @Override
        protected void onCreate (Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_movimentos );

            recebPlaca();

     }


    public void botaoGravar(View view){

        cadastrarMovimentos ();
        sendSMSMessage();

    }

    private void cadastrarMovimentos ( ) {

        edtDataEntrada = findViewById(R.id.edtDataEntradaId);
        edtHoraEntrada = findViewById(R.id.edtHoraEntradaId);
        placaTexto = findViewById(R.id.edtPlacaId);
        edtCelular = findViewById(R.id.edtCelularId);

        String txtPlaca = placaTexto.getText ().toString ().trim ();
        String txtCelul = edtCelular.getText ().toString ().trim ();

        if (!txtCelul.isEmpty ()) {
            if (!txtPlaca.isEmpty ()) {

               Bundle bundle = getIntent().getExtras();
               String e=bundle.getString("emailfor");
               String emailUsuario = e;
               String idUsuario = Base64Custom.codificarBase64( emailUsuario );

               String txtDtEnt = edtDataEntrada.getText ().toString ().trim ();
               String txtHrEnt = edtHoraEntrada.getText ().toString ().trim ();

               movimentos = new MovInfor ();
               movimentos.setEstacio (e);
               movimentos.setFone ( txtCelul );
               movimentos.setPlaca ( txtPlaca );
               movimentos.setDtEntrada ( txtDtEnt );
               movimentos.setHrEntrada ( txtHrEnt  );
               movimentos.setDtSaida (txtDtEnt);
               movimentos.setHrSaida (txtHrEnt);
               movimentos.setTaxa ("I");
               movimentos.setVlrPagar("");
               movimentos.salvar( txtDtEnt,txtHrEnt+txtPlaca);

               finish ();
            } else {
                alert ( "Preencha a Placa !" ); }

        } else {
            alert ( "Preencha o Telefone !" );
        }


        alert ( "gravou!" );



    }


    @Override
    protected void onStart ( ) {
        super.onStart ();
        autenticacao = acessar.getFireAutenticacao ();
    }



    private void recebPlaca ( ) {

            TextView userName = (TextView) findViewById ( R.id.edtPlacaId );
            Bundle bundle = getIntent ().getExtras ();
            String s = bundle.getString ( "placa" );
            String e = bundle.getString ( "emailfor" );
            userName.setText ( s );

            edtDataEntrada = findViewById ( R.id.edtDataEntradaId );
            edtHoraEntrada = findViewById ( R.id.edtHoraEntradaId );

            SimpleDateFormat dateFormat = new SimpleDateFormat ( "dd/MM/yyyy" );
            SimpleDateFormat horaFormat = new SimpleDateFormat ( "HH:mm" );

            Date data = new Date ();

            Calendar cal = Calendar.getInstance ();
            cal.setTime ( data );
            Date data_atual = cal.getTime ();

            String dataUsar = dateFormat.format ( data_atual );
            String hora_atual = horaFormat.format ( data_atual );

            edtDataEntrada.setText ( dataUsar );
            edtHoraEntrada.setText ( hora_atual );
    }

    private void alert (String msg) {
        Toast.makeText ( Movimentos.this, msg, Toast.LENGTH_SHORT ).show ();
    }

    private void sendSMSMessage ( ) {

        edtCelular     = findViewById(R.id.edtCelularId);
        placaTexto     = findViewById(R.id.edtPlacaId);
        edtDataEntrada = findViewById(R.id.edtDataEntradaId);
        edtHoraEntrada = findViewById(R.id.edtHoraEntradaId);


        if((edtCelular.getText().length() > 0 ) && (placaTexto.getText().toString().length() > 0)){
            try {
                SmsManager smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage(edtCelular.getText().toString(), null,
                        " MAPSPARK  [SEJA BEM VINDO] "+"\n"+"\n"+
                                " placa : "+placaTexto.getText().toString()+"\n"+"\n"+
                                " [ ENTRADA ] "+"\n"+
                                " data: "+edtDataEntrada.getText().toString().substring(0,5)+
                                " hora: "+edtHoraEntrada.getText().toString()+"\n"+"\n"+
                                " O seu ponto de parada. ",
                        null, null);
                Toast.makeText(getApplicationContext(), "SMS enviado com sucesso !...", Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Falha no envio do SMS. tente novamente.", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }else{
            Toast.makeText(getApplicationContext(), "Campos obrigatórios"+" \n"+"( Placa / Telefone )", Toast.LENGTH_LONG).show();
        }
    }

}