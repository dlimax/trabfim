package com.mapspark.administra.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.mapspark.administra.R;
import com.mapspark.administra.conexao.acessar;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth autenticacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_main);
    }
    public void btEntrar(View view){startActivity(new Intent (this, Logar.class));    }

    public void btCadastrar(View view){startActivity(new Intent(this, Cadastrar.class));    }

    public void btEncerrar(View view){
        autenticacao = acessar.getFireAutenticacao ();
        autenticacao.signOut();
        alert("Estacionamento deslogado ! " );
        finish ();
    }

    private void alert(String msg){
        Toast.makeText ( MainActivity.this,msg,Toast.LENGTH_SHORT).show ();
    }

}
