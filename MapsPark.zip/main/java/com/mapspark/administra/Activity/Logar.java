package com.mapspark.administra.Activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mapspark.administra.R;
import com.mapspark.administra.conexao.acessar;
import com.mapspark.administra.modelo.Estacionamento;

public class Logar extends AppCompatActivity {

    private FirebaseAuth autenticacao;
    private Estacionamento estacionamento;
    private EditText campoFone, campoEmail, campoSenha;
    private Button botaoLogar;
    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_logar );

        autenticacao = acessar.getFireAutenticacao ();
        inicializaComponentes();
        enventoClicks();

    }

    private void enventoClicks ( ) {
        botaoLogar.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                String txtEmail = campoEmail.getText().toString().trim ();
                String txtSenha = campoSenha.getText().toString().trim ();

                autenticacao = acessar.getFireAutenticacao ();
                autenticacao.signInWithEmailAndPassword (txtEmail, txtSenha).addOnCompleteListener ( new OnCompleteListener<AuthResult> () {
                    @Override
                    public void onComplete (@NonNull Task<AuthResult> task) {
                        if( task.isSuccessful() ){
                            //                           alert("Sucesso ao logar no estacionamento !" );

                            Intent It = new Intent (Logar.this, Gerenciar.class );
                            It.putExtra("emailest", campoEmail.getText ().toString ());

                            startActivity ( It );
                            finish ();
                        }else {
                            alert("Erro ao logar no estacionamento !" );
                        }
                    }
                } );

            }


        } );
    }

    @Override
    protected void onStart ( ) {
        super.onStart ();
        autenticacao= acessar.getFireAutenticacao ();
    }

    private void inicializaComponentes ( ) {
        campoFone = findViewById(R.id.editFone );
        campoEmail = findViewById(R.id.editEmail);
        campoSenha = findViewById(R.id.editSenha);
        botaoLogar    = findViewById( R.id.buttonLogar);
    }

    private void alert(String msg){
        Toast.makeText ( Logar.this,msg,Toast.LENGTH_SHORT).show ();
    }

}