package com.mapspark.administra.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.mapspark.administra.Activity.Finalizar;
import com.mapspark.administra.R;
import com.mapspark.administra.modelo.MovInfor;

import java.util.List;

public class AdapterMovimentacao extends RecyclerView.Adapter<AdapterMovimentacao.MyViewHolder> {

    List<MovInfor> movimentacoes;
    Context context;

    public AdapterMovimentacao(List<MovInfor> movimentacoes,Context context){
        this.movimentacoes = movimentacoes;
        this.context = context;
    }




    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemLista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_adpater, parent, false);
        return new MyViewHolder(itemLista);

    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        final MovInfor movimentacao = movimentacoes.get(position);

        holder.Fone.setText(movimentacao.getFone());
        holder.HrEnrada.setText(movimentacao.getHrEntrada());
        holder.Placa.setText(movimentacao.getPlaca());

        holder.Placa.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                Intent i = new Intent(context, Finalizar.class);
                i.putExtra("emailfor",movimentacao.getEstacio().toString());
                i.putExtra("posicfor",position);

                i.putExtra("inforEstac",movimentacao.getEstacio().toString());
                i.putExtra("inforFone",movimentacao.getFone().toString());
                i.putExtra("inforPlaca",movimentacao.getPlaca().toString());
                i.putExtra("inforDtEnt",movimentacao.getDtEntrada().toString());
                i.putExtra("inforHrEnt",movimentacao.getHrEntrada().toString());
                i.putExtra("inforDtSai",movimentacao.getDtSaida().toString());
                i.putExtra("inforTaxa",movimentacao.getTaxa().toString());
                i.putExtra("inforHrSai",movimentacao.getHrSaida().toString());
                i.putExtra("inforVlrPg",movimentacao.getVlrPagar().toString());
                i.putExtra("inforKey",movimentacao.getKey () );
                context.startActivity(i);

            }
        } );

        holder.HrEnrada.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                envidados();


            }
        } );

        holder.Fone.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                envidados();

            }
        } );


    }

    private void envidados ( ) {



    }


    @Override
    public int getItemCount() {
        return movimentacoes.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView Placa, Fone, HrEnrada;

        public MyViewHolder(View itemView) {
            super(itemView);

            Placa = itemView.findViewById(R.id.textAdapterPlaca);
            Fone = itemView.findViewById(R.id.textAdapterTelefone );
            HrEnrada = itemView.findViewById(R.id.textAdapterHrEntrada);
        }

    }

}

