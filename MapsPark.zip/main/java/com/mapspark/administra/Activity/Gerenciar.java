package com.mapspark.administra.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.mapspark.administra.R;
import com.mapspark.administra.adapter.AdapterMovimentacao;
import com.mapspark.administra.conexao.acessar;
import com.mapspark.administra.helper.Base64Custom;
import com.mapspark.administra.modelo.MovInfor;
import com.miguelcatalan.materialsearchview.MaterialSearchView;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.OnMonthChangedListener;

import java.util.ArrayList;
import java.util.List;

public class Gerenciar extends AppCompatActivity {
    private MaterialCalendarView calendarView;
    private FirebaseAuth autenticacao = acessar.getFireAutenticacao();
    private DatabaseReference firebaseRef = acessar.getFirebaseDatabase();
    private ValueEventListener valueEventListenerMovimentacoes;
    private MaterialSearchView searchView;
    private RecyclerView recyclerView;
    private AdapterMovimentacao adapterMovimentacao;
    private List<MovInfor> movimentacoes = new ArrayList<> ();
    private DatabaseReference movimentacaoRef;
    private String txtDtEnt;
    private String mesSelec;
    private String anoSelec;
    private String diaSelec;
    private MovInfor movimentacao;
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_gerenciar );

        Toolbar toolbar = findViewById ( R.id.toolbar );
        toolbar.setTitle(" ");
        setSupportActionBar ( toolbar );

        Bundle bundle = getIntent().getExtras();
        final String s=bundle.getString("emailest");

        calendarView = findViewById(R.id.calendarView);

        adapterMovimentacao = new AdapterMovimentacao (movimentacoes,this);

        recyclerView = findViewById(R.id.recyclerMovimentos );

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager (this);
        recyclerView.setLayoutManager( layoutManager );
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration ( new DividerItemDecoration ( this,LinearLayoutManager.VERTICAL ) );
        recyclerView.setAdapter( adapterMovimentacao );

        FloatingActionButton fab = findViewById ( R.id.fab );
        fab.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick (View view) {
                Intent It = new Intent (Gerenciar.this, Focar.class );
                It.putExtra("emailfor", s);
                startActivity ( It );
            }
        } );

        configuraCalendarView();
        swipe();
    }

    public void swipe(){

        ItemTouchHelper.Callback itemTouch = new ItemTouchHelper.Callback() {
            @Override
            public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {

                int dragFlags = ItemTouchHelper.ACTION_STATE_IDLE;
                int swipeFlags = ItemTouchHelper.START | ItemTouchHelper.END;
                return makeMovementFlags(dragFlags, swipeFlags);
            }

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                excluirMovimentacao( viewHolder );
            }


        };

        new ItemTouchHelper( itemTouch ).attachToRecyclerView( recyclerView );

    }

    public void excluirMovimentacao(final RecyclerView.ViewHolder viewHolder){

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

        //Configura AlertDialog
        alertDialog.setTitle("Excluir Movimentação da Conta");
        alertDialog.setMessage("Você tem certeza que deseja realmente excluir essa movimentação de sua conta?");
        alertDialog.setCancelable(false);

        alertDialog.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int position = viewHolder.getAdapterPosition();
                movimentacao = movimentacoes.get( position );

                String emailUsuario = autenticacao.getCurrentUser().getEmail();
                String idUsuario = Base64Custom.codificarBase64( emailUsuario );

                movimentacaoRef = firebaseRef.child("MovInfor")
                        .child( idUsuario )
                        .child ( anoSelec);

                movimentacaoRef.child( movimentacao.getKey() ).removeValue();
                adapterMovimentacao.notifyItemRemoved( position );

            }
        });

        alertDialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(Gerenciar.this,
                        "Cancelado",
                        Toast.LENGTH_SHORT).show();
                adapterMovimentacao.notifyDataSetChanged();
            }
        });

        AlertDialog alert = alertDialog.create();
        alert.show();


    }

    private void recuperarMovimentacoes ( ) {

        String emailUsuario = autenticacao.getCurrentUser().getEmail ();
        String idUsuario = Base64Custom.codificarBase64( emailUsuario );


        movimentacaoRef = firebaseRef.child("MovInfor")
                .child( idUsuario )
                .child ( anoSelec);

        valueEventListenerMovimentacoes = movimentacaoRef.addValueEventListener ( new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot dataSnapshot) {
                movimentacoes.clear();
                for (DataSnapshot dados: dataSnapshot.getChildren() ){

                    movimentacao = dados.getValue( MovInfor.class );
                    movimentacao.setKey ( dados.getKey() );
                    movimentacoes.add( movimentacao );
                }

                adapterMovimentacao.notifyDataSetChanged();
            }

            @Override
            public void onCancelled (@NonNull DatabaseError databaseError) {

            }
        } );

    }


    public void configuraCalendarView() {
        calendarView = findViewById(R.id.calendarView);

        CalendarDay dataAtual = calendarView.getCurrentDate();

        diaSelec = String.format("%02d", (dataAtual.getDay()));
        mesSelec = String.format("%02d", (dataAtual.getMonth()+1));
        anoSelec = (diaSelec +"/" +  mesSelec + "/" + dataAtual.getYear());

        calendarView.setOnDateChangedListener ( new OnDateSelectedListener () {
            @Override
            public void onDateSelected (@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {

                diaSelec = String.format("%02d", (date.getDay()));
                mesSelec = String.format("%02d", (date.getMonth()+1));

                anoSelec = (diaSelec +"/" +  mesSelec + "/" + date.getYear());

                alert ( "Dia Selecionado: "+anoSelec );

                recuperarMovimentacoes ();
            }
        } );

    }

    @Override
    protected void onStart ( ) {
        super.onStart ();
        recuperarMovimentacoes();
    }

    @Override
    protected void onStop ( ) {
        super.onStop ();
        movimentacaoRef.removeEventListener( valueEventListenerMovimentacoes );

    }

    private void alert(String msg){
        Toast.makeText ( Gerenciar.this,msg,Toast.LENGTH_SHORT).show ();
    }

}