package com.mapspark.administra.modelo;

public class Estacionamento {

    private String fone;
    private String email;
    private String senha;
    private String cnfsenha;
    private String nome;
    private String tmpdiaria;
    private String vlrdiaria;
    private String tmpfree;
    private String txaHoraria;

    public String getCnfsenha ( ) {
        return cnfsenha;
    }

    public void setCnfsenha (String cnfsenha) {
        this.cnfsenha = cnfsenha;
    }

    public String getNome ( ) {
        return nome;
    }

    public void setNome (String nome) {
        this.nome = nome;
    }

    public String getTmpdiaria ( ) {
        return tmpdiaria;
    }

    public void setTmpdiaria (String tmpdiaria) {
        this.tmpdiaria = tmpdiaria;
    }

    public String getVlrdiaria ( ) {
        return vlrdiaria;
    }

    public void setVlrdiaria (String vlrdiaria) {
        this.vlrdiaria = vlrdiaria;
    }

    public String getTmpfree ( ) {
        return tmpfree;
    }

    public void setTmpfree (String tmpfree) {
        this.tmpfree = tmpfree;
    }

    public String getTxaHoraria ( ) {
        return txaHoraria;
    }

    public void setTxaHoraria (String txaHoraria) {
        this.txaHoraria = txaHoraria;
    }


    public Estacionamento ( ) {

    }

    public String getFone ( ) {
        return fone;
    }

    public void setFone (String fone) {
        this.fone = fone;
    }

    public String getEmail ( ) {
        return email;
    }

    public void setEmail (String email) {
        this.email = email;
    }

    public String getSenha ( ) {
        return senha;
    }

    public void setSenha (String senha) {
        this.senha = senha;
    }
}