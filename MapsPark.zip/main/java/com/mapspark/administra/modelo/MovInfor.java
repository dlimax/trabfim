package com.mapspark.administra.modelo;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.mapspark.administra.conexao.acessar;
import com.mapspark.administra.helper.Base64Custom;
import com.mapspark.administra.helper.DateCustom;

public class MovInfor {

    private String Estacio;
    private String Fone;
    private String Placa;
    private String DtEntrada;
    private String DtSaida;
    private String HrEntrada;
    private String HrSaida;
    private String Taxa;
    private String VlrPagar;
    private String key;

    public MovInfor () {

    }

    public void salvar(String dataEscolhida,String Placa){

        FirebaseAuth autenticacao = acessar.getFireAutenticacao();
        String idUsuario = Base64Custom.codificarBase64( autenticacao.getCurrentUser().getEmail() );
        String idDentif = Base64Custom.codificarBase64( Placa );

        DatabaseReference firebase = acessar.getFirebaseDatabase();
        firebase.child("MovInfor")
                .child( idUsuario )
                .child( dataEscolhida)
                .child( idDentif)
                .setValue(this);
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getEstacio ( ) {
        return Estacio;
    }

    public void setEstacio (String estacio) {
        Estacio = estacio;
    }

    public String getFone ( ) {return Fone;}

    public void setFone (String fone) { this.Fone = fone;  }

    public String getPlaca ( ) {
        return Placa;
    }

    public void setPlaca (String placa) {
        Placa = placa;
    }

    public String getDtEntrada ( ) {
        return DtEntrada;
    }

    public void setDtEntrada (String dtEntrada) {
        DtEntrada = dtEntrada;
    }

    public String getDtSaida ( ) {
        return DtSaida;
    }

    public void setDtSaida (String dtSaida) {
        DtSaida = dtSaida;
    }

    public String getHrEntrada ( ) {
        return HrEntrada;
    }

    public void setHrEntrada (String hrEntrada) {
        HrEntrada = hrEntrada;
    }

    public String getHrSaida ( ) {
        return HrSaida;
    }

    public void setHrSaida (String hrSaida) {
        HrSaida = hrSaida;
    }

    public String getTaxa ( ) {
        return Taxa;
    }

    public void setTaxa (String taxa) { Taxa = taxa;  }

    public String getVlrPagar ( ) {
        return VlrPagar;
    }

    public void setVlrPagar (String vlrPagar) {
        VlrPagar = vlrPagar;
    }

}
