package com.mapspark.administra.Activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.text.Text;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mapspark.administra.R;
import com.mapspark.administra.adapter.AdapterMovimentacao;
import com.mapspark.administra.conexao.acessar;
import com.mapspark.administra.conexao.estacionaLogado;
import com.mapspark.administra.helper.Base64Custom;
import com.mapspark.administra.modelo.Estacionamento;
import com.mapspark.administra.modelo.MovInfor;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Finalizar extends AppCompatActivity {
    private EditText placaTexto;
    private EditText edtCelular;
    private EditText edtDataEntrada;
    private EditText edtDataSaida;
    private EditText edtHoraEntrada;
    private EditText edtHoraSaida;
    private EditText edtValorPagar;
    private EditText edtMensagem;
    private EditText RecEstac;
    private FirebaseAuth autenticacao;
    private DatabaseReference referencia = FirebaseDatabase.getInstance ().getReference ();
    private MovInfor movimentos;
    private AdapterMovimentacao adapterMovimentacao;
    private List<MovInfor> movimentacoes = new ArrayList<> ();
    private MovInfor movimentacao;
    private DatabaseReference movimentacaoRef;
    private String idEstacioLogado;

    private EditText editEstacNome, editEstacTmpLiv,
            editTxaHora, editTmpDiar,editVlrDiar;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_finalizar );

        recebFim();

        movimentacaoRef = acessar.getFirebaseDatabase ();
        idEstacioLogado = estacionaLogado.getIdEstacio();

        recuperarDadosEmpresa();
    }


    public void botaoSms(View view){

        sendSMSMessage();

    }

    public void botaoPreco(View view){

        CalcValor();

    }

    private void recuperarDadosEmpresa(){

        DatabaseReference empresaRef = movimentacaoRef
                .child("Estacionamento")
                .child( idEstacioLogado );
        empresaRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if( dataSnapshot.getValue() != null ){

                    Estacionamento estacionamento = dataSnapshot.getValue(Estacionamento.class);
                    editEstacNome.setText(estacionamento.getNome());
                    editEstacTmpLiv.setText(estacionamento.getTmpfree());
                    editTxaHora.setText(estacionamento.getTxaHoraria().toString());
                    editTmpDiar.setText(estacionamento.getTmpdiaria());
                    editVlrDiar.setText(estacionamento.getVlrdiaria());

                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void CalcValor ( ) {

        edtDataEntrada = findViewById(R.id.edtDataEntradaId);
        edtDataSaida = findViewById(R.id.edtDataSaidaId);
        edtHoraEntrada = findViewById(R.id.edtHoraEntradaId);
        edtHoraSaida = findViewById(R.id.edtHoraSaidaId);
        edtValorPagar = findViewById(R.id.edtValorPagarId);

        SimpleDateFormat dateFormat = new SimpleDateFormat ( "dd/MM/yyyy" );
        SimpleDateFormat horaFormat = new SimpleDateFormat ( "HH:mm" );

        Date data = new Date ();

        Calendar cal = Calendar.getInstance ();
        cal.setTime ( data );
        Date data_atual = cal.getTime ();

        String dataUsar = dateFormat.format ( data_atual );
        String hora_atual = horaFormat.format ( data_atual );

        edtDataSaida.setText ( dataUsar );
        edtHoraSaida.setText ( hora_atual );


        Date dataE ;
        Date dataS;

        String dateTimeEntrada;
        String dateTimeSaida;

        Double valorTotal;

        dateTimeEntrada = edtDataEntrada.getText().toString()+ " "+ edtHoraEntrada.getText().toString()+":00";
        dateTimeSaida = edtDataSaida.getText().toString()+ " "+ edtHoraSaida.getText().toString()+":00";

        try{
            DateFormat formatter = new SimpleDateFormat("MM/dd/yy");
            dataE = stringToDate(dateTimeEntrada,"dd/mm/yyyy HH:mm:ss");
            dataS = stringToDate(dateTimeSaida,"dd/mm/yyyy HH:mm:ss");
            long horas = (dataS.getTime() - dataE.getTime()) / 3600000;
            long minutos = (dataS.getTime() - dataE.getTime() - horas*3600000) / 60000;
            DecimalFormat dfValor = new DecimalFormat("#.00");
            dfValor.format((0.0833 * (minutos + (horas * 60))));
            // edtValorPagar.setText("R$ "+String.valueOf((0.0833 * (minutos + (horas * 60)))));


            DecimalFormat format = new DecimalFormat("##,###,###,##0.00",
                    new DecimalFormatSymbols (new Locale ("pt", "BR")));
            format.setMinimumFractionDigits(2);
            format.setParseBigDecimal (true);
            // edtValorPagar.setText("R$ "+format.format((0.0833 * (minutos + (horas * 60)))));


            // int i = (int) ((Math.floor(minutos + (horas * 60))) / 15);(Math.floor(minutos + (horas * 60))) / 15);



            int val = (int) ((Math.floor(minutos + (horas * 60))) / 15);




            if((val <  (minutos + (horas * 60))) && ((minutos + (horas * 60)) % 15 != 0))
                val = val + 1;

            // edtValorPagar.setText("R$ "+format.format((Math.floor((minutos + (horas * 60)) / 15) )));
            edtValorPagar.setText("R$ "+format.format( val * 1.25));



        }catch (Exception e){
            Toast.makeText(this, "Verifique os campos data e hora ("+dateTimeEntrada+" / "+dateTimeSaida+")!", Toast.LENGTH_SHORT).show();
        }


    }

    private Date stringToDate(String aDate,String aFormat) {

        if(aDate==null) return null;
        ParsePosition pos = new ParsePosition(0);
        SimpleDateFormat simpledateformat = new SimpleDateFormat(aFormat);
        Date stringDate = simpledateformat.parse(aDate, pos);
        return stringDate;

    }


    private void recebFim ( ) {

        TextView DisPlaca = (TextView) findViewById ( R.id.edtPlacaId );
        TextView DisFone = findViewById ( R.id.edtCelularId );
        TextView DisDtEnt = findViewById ( R.id.edtDataEntradaId );
        TextView DisHrEnt = findViewById ( R.id.edtHoraEntradaId );
        TextView DisDtSai = findViewById ( R.id.edtDataSaidaId );
        TextView DisHrSai = findViewById ( R.id.edtHoraSaidaId );
        TextView DisVlrPg = findViewById ( R.id.edtValorPagarId );
        TextView DisTexto = findViewById ( R.id.numControleId2);

        Bundle bundle = getIntent ().getExtras ();
        String RecEstac= bundle.getString ( "inforEstac" );
        String RecFone = bundle.getString ( "inforFone" );
        String RecPlaca = bundle.getString ( "inforPlaca" );
        String RecDtEnt = bundle.getString ( "inforDtEnt" );
        String RecHrEnt = bundle.getString ( "inforHrEnt" );
        String RecDtSai = bundle.getString ( "inforDtSai" );
        String RecTaxa = bundle.getString ( "inforTaxa" );
        String RecHrSai = bundle.getString ( "inforHrSai" );
        String RecVlrPg = bundle.getString ( "inforVlrPg" );

        DisPlaca.setText ( RecPlaca );
        DisFone.setText ( RecFone );
        DisDtEnt.setText ( RecDtEnt );
        DisHrEnt.setText ( RecHrEnt );

        if (RecTaxa.toString ().equals ( "F" )) {
            DisDtSai.setText ( RecDtSai );
            DisHrSai.setText ( RecHrSai );
            DisVlrPg.setText ( RecVlrPg );
            DisTexto.setText ( "Recibo Pagto" );

        } else {

            DisDtSai.setText ( "  /  /  " );
            DisHrSai.setText ( "  :  " );
            DisVlrPg.setText ( "   0.0" );
            DisTexto.setText ( "Comprovante" );
            //      DisVlrPg.setText ( "0.0" );
        }

    }

    private void sendSMSMessage ( ) {

        edtCelular     = findViewById(R.id.edtCelularId);
        placaTexto     = findViewById(R.id.edtPlacaId);
        edtDataEntrada = findViewById(R.id.edtDataEntradaId);
        edtHoraEntrada = findViewById(R.id.edtHoraEntradaId);
        edtDataSaida   = findViewById(R.id.edtDataSaidaId);
        edtHoraSaida   = findViewById(R.id.edtHoraSaidaId);
        edtValorPagar  = findViewById(R.id.edtValorPagarId);
        TextView DisTexto = findViewById ( R.id.numControleId2);

        if((edtCelular.getText().length() > 0 ) && (placaTexto.getText().toString().length() > 0)){
            try {
                SmsManager smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage(edtCelular.getText().toString(), null,
                        " MAPSPARK  ["+DisTexto.getText().toString()+"] "+"\n"+"\n"+
                                " placa : "+placaTexto.getText().toString()+"\n"+"\n"+
                                " [ ENTRADA ] "+"\n"+
                                " data: "+edtDataEntrada.getText().toString().substring(0,5)+
                                " hora: "+edtHoraEntrada.getText().toString()+"\n"+"\n"+
                                " [ SAIDA ] "+"\n"+
                                " data: "+edtDataSaida.getText().toString().substring(0,5)+
                                " hora: "+edtHoraSaida.getText().toString()+"\n"+"\n"+
                                " R$: "+edtValorPagar.getText().toString(),
                        null, null);

                Toast.makeText(getApplicationContext(), "SMS enviado com sucesso !...", Toast.LENGTH_LONG).show();
                AltearMovimentos();

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Falha no envio do SMS. tente novamente.", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }else{
            Toast.makeText(getApplicationContext(), "Campos obrigatórios"+" \n"+"( Placa / Telefone )", Toast.LENGTH_LONG).show();
        }
    }

    private void AltearMovimentos ( ) {

        Bundle bundle = getIntent().getExtras();
        String e=bundle.getString("emailfor");
        int  cPo=bundle.getInt ("posicfor");
        String RecKey= bundle.getString ( "inforKey" );
        String emailUsuario = e;
        String idUsuario = Base64Custom.codificarBase64( emailUsuario );

        edtCelular     = findViewById(R.id.edtCelularId);
        placaTexto     = findViewById(R.id.edtPlacaId);
        edtDataEntrada = findViewById(R.id.edtDataEntradaId);
        edtHoraEntrada = findViewById(R.id.edtHoraEntradaId);
        edtDataSaida   = findViewById(R.id.edtDataSaidaId);
        edtHoraSaida   = findViewById(R.id.edtHoraSaidaId);
        edtValorPagar  = findViewById(R.id.edtValorPagarId);

        String txtPlaca = placaTexto.getText ().toString ().trim ();
        String txtCelul = edtCelular.getText ().toString ().trim ();
        String txtDtEnt = edtDataEntrada.getText ().toString ().trim ();
        String txtHrEnt = edtHoraEntrada.getText ().toString ().trim ();
        String txtDtSai = edtDataSaida.getText ().toString ().trim ();
        String txtHrSai = edtHoraSaida.getText ().toString ().trim ();
        String txtValor = edtValorPagar.getText ().toString ().trim ();

        movimentos = new MovInfor ();
        movimentos.setEstacio (e);
        movimentos.setFone ( txtCelul );
        movimentos.setPlaca ( txtPlaca );
        movimentos.setDtEntrada ( txtDtEnt );
        movimentos.setHrEntrada ( txtHrEnt  );
        movimentos.setDtSaida (txtDtSai);
        movimentos.setHrSaida (txtDtSai);
        movimentos.setTaxa ("F");
        movimentos.setVlrPagar(txtValor);
        movimentos.salvar( txtDtEnt,txtHrEnt+txtPlaca );
        finish ();

    }

    private void alert (String msg) {
        Toast.makeText ( Finalizar.this, msg, Toast.LENGTH_SHORT ).show ();
    }
}