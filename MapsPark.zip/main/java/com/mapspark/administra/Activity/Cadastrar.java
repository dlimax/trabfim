package com.mapspark.administra.Activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mapspark.administra.R;
import com.mapspark.administra.conexao.acessar;
import com.mapspark.administra.modelo.Estacionamento;

public class Cadastrar extends AppCompatActivity {
    private FirebaseAuth autenticacao;
    private Estacionamento estacionamento;
    private EditText campoFone, campoEmail, campoSenha,campoNome,campoCnfSenha,campoVlrDia,campoTxHora,campoTpMin,campoTpDia;
    private Button botaoCadastrar;
    private DatabaseReference referencia = FirebaseDatabase.getInstance ().getReference ();

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_cadastrar );

        autenticacao = acessar.getFireAutenticacao ();

        inicializaComponentes ();
        enventoClicks ();

    }

    private void enventoClicks ( ) {
        botaoCadastrar.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                String textoFone     = campoFone.getText ().toString ().trim ();
                String textoEmail    = campoEmail.getText ().toString ().trim ();
                String textoSenha    = campoSenha.getText ().toString ().trim ();
                String textoNome     = campoNome.getText ().toString ().trim ();
                String textoCnfSenha = campoCnfSenha.getText ().toString ().trim ();
                String textoVlrDia   = campoVlrDia.getText ().toString ().trim ();
                String textoTxHora   = campoTxHora.getText ().toString ().trim ();
                String textoTpMin    = campoTpMin.getText ().toString ().trim ();
                String textoTpDia    = campoTpDia.getText ().toString ().trim ();

                if (!textoFone.isEmpty ()) {
                    if (!textoEmail.isEmpty ()) {
                        if (!textoSenha.isEmpty ()) {

                            estacionamento = new Estacionamento ();
                            estacionamento.setFone ( textoFone );
                            estacionamento.setEmail ( textoEmail );
                            estacionamento.setSenha ( textoSenha );
                            estacionamento.setNome ( textoNome );
                            estacionamento.setCnfsenha ( textoCnfSenha );
                            estacionamento.setVlrdiaria ( textoVlrDia );
                            estacionamento.setTxaHoraria ( textoTxHora );
                            estacionamento.setTmpfree ( textoTpMin );
                            estacionamento.setTmpdiaria ( textoTpDia );

                            cadastrarEstacionamento ();

                        } else {
                            alert ( "Preencha a senha ! " );
                        }
                    } else {
                        alert ( "Preencha o email !" );

                    }
                } else {
                    alert ( "Preencha o Telefone !" );
                }


            }
        } );
    }

    private void gravarregistro ( ) {
        DatabaseReference estacione = referencia.child ( "Estacionamento" );
        estacione.addValueEventListener ( new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onCancelled (@NonNull DatabaseError databaseError) {

            }
        } );

        String textoFone = campoFone.getText ().toString ().trim ();
        String textoEmail = campoEmail.getText ().toString ().trim ();
        String textoSenha = campoSenha.getText ().toString ().trim ();
        String textoNome     = campoNome.getText ().toString ().trim ();
        String textoCnfSenha = campoCnfSenha.getText ().toString ().trim ();
        String textoVlrDia   = campoVlrDia.getText ().toString ().trim ();
        String textoTxHora   = campoTxHora.getText ().toString ().trim ();
        String textoTpMin    = campoTpMin.getText ().toString ().trim ();
        String textoTpDia    = campoTpDia.getText ().toString ().trim ();

        estacionamento = new Estacionamento ();
        estacionamento.setFone ( textoFone );
        estacionamento.setEmail ( textoEmail );
        estacionamento.setSenha ( textoSenha );
        estacionamento.setNome ( textoNome );
        estacionamento.setCnfsenha ( textoCnfSenha );
        estacionamento.setVlrdiaria ( textoVlrDia );
        estacionamento.setTxaHoraria ( textoTxHora );
        estacionamento.setTmpfree ( textoTpMin );
        estacionamento.setTmpdiaria ( textoTpDia );

        estacione.push ().setValue ( estacionamento );
    }

    @Override
    protected void onStart ( ) {
        super.onStart ();
        autenticacao = acessar.getFireAutenticacao ();
    }

    private void cadastrarEstacionamento ( ) {
        autenticacao = acessar.getFireAutenticacao ();
        autenticacao.createUserWithEmailAndPassword ( estacionamento.getEmail (), estacionamento.getSenha () ).addOnCompleteListener ( this, new OnCompleteListener<AuthResult> () {
            @Override
            public void onComplete (@NonNull Task<AuthResult> task) {
                if (task.isSuccessful ()) {
                    alert ( "Sucesso ao cadastrar estacionamento ! " );
                    gravarregistro ();
                    Intent i = new Intent ( Cadastrar.this, Gerenciar.class );

                    i.putExtra("emailest", campoEmail.getText ().toString ());

                    startActivity ( i );
                    finish ();
                } else {
                    alert ( "Erro ao cadastrar estacinamento ! " );
                }
            }
        } );
    }


    private void inicializaComponentes ( ) {
        campoFone     = findViewById ( R.id.editFone );
        campoEmail    = findViewById ( R.id.editEmail );
        campoSenha    = findViewById ( R.id.editSenha );
        campoNome     = findViewById ( R.id.editNome);
        campoCnfSenha = findViewById ( R.id.editCnfSenha);
        campoVlrDia   = findViewById ( R.id.idVlrDia);
        campoTxHora   = findViewById ( R.id.idTxHora);
        campoTpMin    = findViewById ( R.id.IdTpMin);
        campoTpDia    = findViewById ( R.id.idTpDia);


        botaoCadastrar = findViewById ( R.id.buttonCadastrar );
    }

    private void alert (String msg) {
        Toast.makeText ( Cadastrar.this, msg, Toast.LENGTH_SHORT ).show ();
    }
}